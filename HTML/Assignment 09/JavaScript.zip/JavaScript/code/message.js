function msg(){  
 alert("Hello Student");  
}  