<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>File Upload</title>
</head>
<body>
	<form action="upload.php" method="POST" enctype="multipart/form-data">
		<input type="file" name="image">
		<button>Submit</button>
	</form>
</body>
</html>