<?php            // save the file named "test.php"
	class Demo 
	{
		public $name;

		function SayHello($n)
		{
			echo "Hello: ". $n;
		}

 	}	 
?>
