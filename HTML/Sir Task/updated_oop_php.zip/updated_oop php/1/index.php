<?php 
	require_once('test.php'); 
	$objDemo = new Demo(); 
	$objDemo->name = "How are You All";
	$objDemo->SayHello($objDemo->name);
?> 
