<div id="header">
	<div id="content">
    <label>PHP Database Operation Using OOP</label>
    </div>
</div>