<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP Database Operation Using OOP</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>
<body>
<center>
<?php
include_once 'header.php';
?>
<div id="body">
	<div id="content">
    <table align="center">
    <tr>
    <th colspan="2"> Insert <a href="add_data.php"><img src="b_insert.jpg" alt="insert" height="42" width="42"/></a></th>
	<th colspan="3"> View <a href="view.php"><img src="b_view.jpg" alt="view" height="42" width="42"/></a></th>
    </tr>
	
    </table>
    </div>
</div>
<?php
include_once 'footer.php';
?>
</center>
</body>
</html>