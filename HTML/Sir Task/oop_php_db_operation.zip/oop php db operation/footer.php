<div id="footer">
	<div id="content">
    <hr /><br/>
    <label>PHP OOP OPERATION</a></label>
    </div>
</div>