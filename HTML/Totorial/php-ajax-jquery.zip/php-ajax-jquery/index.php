<?php include 'inc/header.php'; ?>
<h2>Topics: Project List</h2>
<div class="content">
	<div class="topics">
		<ul>
			<li><a href="" target="_blank">01</a></li>
		</ul>
	</div>
</div>
<?php include 'inc/footer.php'; ?>