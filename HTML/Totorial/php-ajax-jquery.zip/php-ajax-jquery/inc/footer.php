 </section>
<section class="footeroption">
		<h2><?php echo "www.trainingwithliveproject.com"; ?></h2>
	</section>
</div>
</body>
</html>