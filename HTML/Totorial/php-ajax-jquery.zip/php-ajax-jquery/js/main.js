$(document).ready(function(){ 
  
 });  