<html>
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Live Searching</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
 </head>
 <body>
  <div class="container">
   <br />
   <h2 align="center">Ajax Live Data Search using Jquery</h2><br />
   <div class="form-group">
    <div class="input-group">
     <span class="input-group-addon">Search</span>
     <input type="text" name="search_text" id="search_text" placeholder="Search by Customer Details" class="form-control" />
    </div>
   </div>
   <br />
   <div id="result"></div>
  </div>
 </body>
</html>


<script>
$(document).ready(function(){ // A page can't be manipulated safely until the document is "ready." jQuery detects this state . $( document ).ready() will only run once the page Document Object Model (DOM) is ready for JavaScript code to execute.

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",   // The data are send to the "fetch.php" file through POST method.
   method:"POST",
   data:{query:query},     
   success:function(data)     // The response from the server is placed into an HTML element which has id="result". This is output of ajax function
   {
    $('#result').html(data);    
   }
  });
 }
 $('#search_text').keyup(function(){    // jquery key-upevent
  var search = $(this).val();           // set search text to search variable
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>